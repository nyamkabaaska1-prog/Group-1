import scrapy
import re

class GithubSpider(scrapy.Spider):
    name = "github"
    allowed_domains = ["github.com"]
    
    def __init__(self, username="trungvdhp", *args, **kwargs):
        super(GithubSpider, self).__init__(*args, **kwargs)
        self.username = username
        self.start_urls = [f"https://github.com/{username}?tab=repositories"]

    def parse(self, response):
        repositories = response.css('li[itemprop="owns"]')
        for repo_item in repositories:
            repo_rel_url = repo_item.css('h3 a::attr(href)').get()
            if repo_rel_url:
                repo_url = response.urljoin(repo_rel_url)
                name = repo_item.css('h3 a::text').get().strip()
                about = repo_item.css('p[itemprop="description"]::text').get()
                last_updated = repo_item.css('relative-time::attr(datetime)').get()
                
                yield scrapy.Request(
                    repo_url, 
                    callback=self.parse_repository,
                    meta={
                        'name': name,
                        'url': repo_url,
                        'about': about.strip() if about else "",
                        'last_updated': last_updated
                    }
                )

        next_page = response.css('div.paginate-container a:contains("Next")::attr(href)').get()
        if next_page:
            yield response.follow(next_page, self.parse)

    def parse_repository(self, response):
        meta = response.meta
        
        # Check if the repository is empty
        # A repository is NOT empty if it has a file tree or languages listed.
        # Truly empty repos show a blankslate or a "This repository is empty" message.
        is_empty_msg = "This repository is empty." in response.text
        is_blankslate = response.css('div.blankslate').get() is not None
        
        # If we find languages or a file list, it's definitely NOT empty
        has_languages = response.xpath('//h2[text()="Languages"]').get() is not None
        has_files = response.css('div.react-directory-row').get() is not None
        
        is_empty = (is_empty_msg or is_blankslate) and not (has_languages or has_files)
        
        # About Logic
        about = meta['about']
        if not about and not is_empty:
            about = meta['name']
            
        # Languages and Commits
        if not is_empty:
            # Languages extraction: more precise spans
            langs = response.css('li.d-inline a span.text-bold::text').getall()
            if not langs:
                langs = response.xpath("//h2[text()='Languages']/following-sibling::ul/li/a/span[1]/text()").getall()
            
            languages_str = ", ".join(sorted(list(set([l.strip() for l in langs if l.strip()]))))
            if not languages_str:
                languages_str = "None"
            
            # Commits extraction
            # Re-scoping to the exact verified pattern
            commits_text = response.xpath('//a[contains(@href, "/commits/")]//span[contains(text(), "Commits")]/text()').get()
            if not commits_text:
                # Fallback to general commit link text
                commits_text = response.xpath('//a[contains(@href, "/commits/")]//span/text()').get()
            
            if commits_text:
                num_commits = "".join(re.findall(r'\d+', commits_text.replace(',', '')))
            else:
                num_commits = "0"
        else:
            languages_str = "None"
            num_commits = "None"
            
        yield {
            'URL': meta['url'],
            'About': about,
            'Last_Updated': meta['last_updated'],
            'Languages': languages_str,
            'Number_of_Commits': num_commits
        }
