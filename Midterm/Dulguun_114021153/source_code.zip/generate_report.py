import xml.etree.ElementTree as ET
from fpdf import FPDF
import datetime

class RepoReport(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 15)
        self.cell(0, 10, 'GitHub Repository Report', 0, 1, 'C')
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

def generate_pdf(xml_file, pdf_file):
    try:
        tree = ET.parse(xml_file)
        root = tree.getroot()
    except Exception as e:
        print(f"Error parsing XML: {e}")
        return

    pdf = RepoReport()
    pdf.add_page()
    pdf.set_font("Arial", size=10)

    # Table Header
    pdf.set_fill_color(200, 220, 255)
    pdf.set_font("Arial", 'B', 10)
    pdf.cell(10, 10, 'No', 1, 0, 'C', 1)
    pdf.cell(60, 10, 'Repository Name', 1, 0, 'C', 1)
    pdf.cell(30, 10, 'Last Updated', 1, 0, 'C', 1)
    pdf.cell(60, 10, 'Languages', 1, 0, 'C', 1)
    pdf.cell(30, 10, 'Commits', 1, 1, 'C', 1)

    pdf.set_font("Arial", size=9)
    count = 1
    for item in root.findall('item'):
        url = item.find('URL').text
        name = url.split('/')[-1]
        last_updated = item.find('Last_Updated').text[:10] if item.find('Last_Updated').text else "N/A"
        languages = item.find('Languages').text or "None"
        commits = item.find('Number_of_Commits').text or "None"

        # Handle long text for name and languages by using multi_cell or truncating
        name_display = name if len(name) < 30 else name[:27] + "..."
        langs_display = languages if len(languages) < 35 else languages[:32] + "..."

        pdf.cell(10, 8, str(count), 1, 0, 'C')
        pdf.cell(60, 8, name_display, 1, 0, 'L')
        pdf.cell(30, 8, last_updated, 1, 0, 'C')
        pdf.cell(60, 8, langs_display, 1, 0, 'L')
        pdf.cell(30, 8, commits, 1, 1, 'C')
        
        count += 1

    pdf.output(pdf_file)
    print(f"Report generated: {pdf_file}")

if __name__ == "__main__":
    generate_pdf("repositories.xml", "report.pdf")
