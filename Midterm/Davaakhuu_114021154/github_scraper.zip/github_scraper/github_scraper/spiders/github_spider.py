import scrapy
from urllib.parse import urljoin


class GithubSpider(scrapy.Spider):
    name = "github_spider"
    allowed_domains = ["github.com"]

    github_username = "trungvdhp"
    start_urls = [f"https://github.com/{github_username}?tab=repositories"]

    def parse(self, response):
        repo_links = response.css('a[itemprop="name codeRepository"]::attr(href)').getall()

        for repo_link in repo_links:
            full_repo_url = urljoin("https://github.com", repo_link)
            yield scrapy.Request(
                url=full_repo_url,
                callback=self.parse_repo,
                meta={"repo_url": full_repo_url}
            )

        next_page = response.css('a.next_page::attr(href)').get()
        if next_page:
            yield response.follow(next_page, callback=self.parse)

    def parse_repo(self, response):
        repo_url = response.meta["repo_url"]

        repo_name = response.url.rstrip("/").split("/")[-1]

        about = response.css('p.f4.my-3::text, p.color-fg-muted.my-3::text').get()
        if about:
            about = about.strip()

        last_updated = response.css('relative-time::attr(datetime)').get()

        page_text = " ".join(response.css("body *::text").getall())
        is_empty = "This repository is empty." in page_text

        if not about:
            if not is_empty:
                about = repo_name
            else:
                about = None

        if is_empty:
            languages = None
            commits = None
        else:
            languages = response.css(
                'span[itemprop="programmingLanguage"]::text, '
                'li span.color-fg-default.text-bold.mr-1::text'
            ).getall()
            languages = [lang.strip() for lang in languages if lang.strip()]
            if not languages:
                languages = None

            commits = None

            commit_link_texts = response.css('a[href*="/commits/"]::text').getall()
            for text in commit_link_texts:
                text = text.strip()
                if any(ch.isdigit() for ch in text):
                    commits = text.replace(",", "")
                    break

        yield {
            "url": repo_url,
            "about": about,
            "last_updated": last_updated,
            "languages": ", ".join(languages) if languages else None,
            "commits": commits
        }