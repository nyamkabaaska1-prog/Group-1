import scrapy
from githubProject.items import GithubItem

class GithubSpider(scrapy.Spider):
    name = "github" # This MUST match the terminal command
    # Using the teacher's profile as the target
    start_urls = ['https://github.com/trungvdhp?tab=repositories']

    def parse(self, response):
        # Targeting the repository list items specifically
        for repo in response.css('div#user-repositories-list li'):
            item = GithubItem()
            
            # Name and URL extraction [cite: 302, 303]
            name = repo.css('h3 a::text').get()
            if name:
                item['name'] = name.strip()
                item['url'] = response.urljoin(repo.css('h3 a::attr(href)').get())
                
                # REQUIREMENT 1: Fallback About logic
                about = repo.css('p[itemprop="description"]::text').get()
                item['about'] = about.strip() if about else item['name']
                
                # Metadata from the list [cite: 307-312]
                item['languages'] = repo.css('span[itemprop="programmingLanguage"]::text').get()
                item['lastUpdated'] = repo.css('relative-time::attr(datetime)').get()
                
                # Deep scraping for commits [cite: 183-184]
                yield scrapy.Request(item['url'], callback=self.parse_details, meta={'item': item})

    def parse_details(self, response):
        item = response.meta['item']
        # Target the commit count on the specific repo page
        commits = response.css('span.d-none.d-sm-inline strong::text').get()
        
        # Empty repo logic
        if commits:
            item['commits'] = commits.strip()
        else:
            item['commits'] = "None"
            if not item['languages']:
                item['languages'] = "None"
                
        yield item
        