# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from dateutil import parser

class GithubPipeline:
    def process_item(self, item, spider):
        if item.get('lastUpdated'):
            date_obj = parser.parse(item['lastUpdated'])
            item['lastUpdated'] = date_obj.strftime('%d %B %Y, at %H:%M.')
        return item

